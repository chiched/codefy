// add external CSS stylesheet
// var link = document.createElement('link'); 
// link.rel = 'stylesheet';  
// link.type = 'text/css'; 
// link.href = browser.runtime.getURL("beforeLoad.css");
// document.documentElement.append(link); 

console.log('start.js started');


